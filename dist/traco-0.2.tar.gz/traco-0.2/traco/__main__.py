from .source import main

main()
