from setuptools import setup

setup(
    name='traco',
    version='0.1',
    description="Correction of translocation defects in crystals",
    author="Petr Kolenko",
    author_email='kolenpe1@cvut.cz',
    license='',
    url='https://github.com/kolenpe1/traco',
    py_modules=['traco'],
)
